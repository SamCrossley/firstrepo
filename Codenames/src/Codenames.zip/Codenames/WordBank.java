package Codenames;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class WordBank {
	
	private String word;
	
	  List<WordBank> bank1 = new ArrayList<WordBank>();
	 
	 public WordBank(String word) {
		 
		 this.word = word;
	 }
	 
	
		 
	 
	 public List<WordBank> bufferedRead(String inFile) throws IOException
		{
			
		//inFile = "bank1.txt";	
		BufferedReader bfdIn = new BufferedReader(new FileReader(inFile));
		bfdIn.readLine();
		String input = null;
		while ((input = bfdIn.readLine()) != null) {
			String[] line = input.split(",");
			WordBank word = new WordBank(line[0]);
			bank1.add(word);
		
		}
		Collections.shuffle(bank1);
	return bank1;
	

}
	 
}