package Codenames;

import java.io.IOException;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		WordBank test = new WordBank("Adil");
		System.out.println(test.bufferedRead("C:\\Users\\Admin\\eclipse-workspace\\Codenames\\src\\Codenames\\bank1.txt"));
		
	}

}
