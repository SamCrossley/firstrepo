package Codenames;

public class Card {
	private String word;
	private boolean isPicked;
	
	public Card(String word, boolean isPicked) {
		this.word = word;
		this.isPicked = isPicked;
	}
	public String getWord() {
		return word;
	}
	public boolean getIsPicked() {
		return isPicked;
	}
	

}
