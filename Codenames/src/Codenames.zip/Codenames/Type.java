package Codenames;

public enum Type {
	RED, BLUE, BLACK, YELLOW;
}

